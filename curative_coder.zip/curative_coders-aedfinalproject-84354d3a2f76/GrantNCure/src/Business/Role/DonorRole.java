/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Role;

import Business.EcoSystem;
import Business.Enterprise.Enterprise;
import Business.Network.Network;
import Business.Organization.DonorAidOrganization;
import Business.Organization.HospitalistOrganization;
import Business.Organization.Organization;
import Business.User.Organization.DonorOrganization;
import Business.UserAccount.UserAccount;
import Business.UserInfo.DonorInfo;
import javax.swing.JPanel;
import userinterface.DoctorRole.DoctorWorkAreaJPanel;
import userinterface.DonorRole.DonorWorkAreaJPanel;
/**
 *
 * @author Richa Singh
 */
    
   public class DonorRole extends Role{

    @Override

    public JPanel createWorkArea(JPanel userProcessContainer, UserAccount account, Organization organization, Enterprise enterprise ,EcoSystem system) {
        return new DonorWorkAreaJPanel(userProcessContainer, new DonorInfo(), enterprise, EcoSystem.getInstance()); //To change body of generated methods, choose Tools | Templates.

    }
    
}


