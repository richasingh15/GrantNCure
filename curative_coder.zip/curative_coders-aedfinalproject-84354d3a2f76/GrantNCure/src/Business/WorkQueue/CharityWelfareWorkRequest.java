/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

/**
 *
 * @author manish
 */
public class CharityWelfareWorkRequest extends WorkRequest {

    private Double amount;
    private boolean transferred;
    private HospitalToCharityWorkRequest hospitalToCharityWorkRequest;

    public HospitalToCharityWorkRequest getHospitalToCharityWorkRequest() {
        return hospitalToCharityWorkRequest;
    }

    public void setHospitalToCharityWorkRequest(HospitalToCharityWorkRequest hospitalToCharityWorkRequest) {
        this.hospitalToCharityWorkRequest = hospitalToCharityWorkRequest;
    }

    public boolean isTransferred() {
        return transferred;
    }

    public void setTransferred(boolean transferred) {
        this.transferred = transferred;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return amount + "";
    }
    
}
