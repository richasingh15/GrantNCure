/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.WorkQueue;

import Business.Enterprise.Enterprise;

/**
 *
 * @author manish
 */
public class HospitalToCharityWorkRequest extends WorkRequest{
    
   
//    private String approval;    
    private Double amount;
    private String hospital;
    private Enterprise requestingEnterprise;

    public Enterprise getRequestingEnterprise() {
        return requestingEnterprise;
    }

    public void setRequestingEnterprise(Enterprise requestingEnterprise) {
        this.requestingEnterprise = requestingEnterprise;
    }
    
    public String getHospital() {
        return hospital;
    }

    public void setHospital(String hospital) {
        this.hospital = hospital;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

//
//    public String getApproval() {
//        return approval;
//    }
//
//    public void setApproval(String approval) {
//        this.approval = approval;
//    }

    

    
}