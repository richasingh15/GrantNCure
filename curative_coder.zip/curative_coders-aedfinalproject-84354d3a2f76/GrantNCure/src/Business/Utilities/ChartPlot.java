/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Utilities;

/**
 *
 * @author manish
 */
import java.util.ArrayList;
import javax.swing.JFrame;  
import javax.swing.SwingUtilities;  
import javax.swing.WindowConstants;
  
import org.jfree.chart.ChartFactory;  
import org.jfree.chart.ChartPanel;  
import org.jfree.chart.JFreeChart;  
import org.jfree.chart.plot.PlotOrientation;  
import org.jfree.data.category.CategoryDataset;  
import org.jfree.data.category.DefaultCategoryDataset; 

public class ChartPlot extends JFrame {  
  
  private static final long serialVersionUID = 1L;  
  private ArrayList<ArrayList<String> > xyData;
  public ChartPlot(String appTitle, ArrayList<ArrayList<String> > xyData) {  
    super(appTitle);  
    this.xyData = xyData;
    // Create Dataset  
    CategoryDataset dataset = createDataset();  
      
    //Create chart  
    JFreeChart chart=ChartFactory.createBarChart(  
        "Donor and thier Donations",
        "Donors", 
        "Donations",
        dataset,  
        PlotOrientation.VERTICAL,  
        true,true,false  
       );  
  
    ChartPanel panel=new ChartPanel(chart);  
    setContentPane(panel);  
  }  
  
  private CategoryDataset createDataset() {  
    DefaultCategoryDataset dataset = new DefaultCategoryDataset();  
    for(ArrayList<String> data: xyData) {
        String xCoordinate = data.get(0);        
        String yCoordinate = data.get(1);
        dataset.addValue(Integer.parseInt(yCoordinate), "Donor", xCoordinate);  
    }
//    dataset.addValue(15, "Donor", "Manish");  
//    dataset.addValue(25, "Donor", "Richa");  
//    dataset.addValue(25, "Donor", "Vivek");  
//    dataset.addValue(25, "Donor", "Adwait");
  
    return dataset;  
  }  

}