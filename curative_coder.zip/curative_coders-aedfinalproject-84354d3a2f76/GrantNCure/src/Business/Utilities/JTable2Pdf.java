/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Utilities;
import java.io.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.event.*;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

public class JTable2Pdf {
    private JTable table;
    private JButton button;
//public static void main(String[] args) {
//new JTable2Pdf();
//}

    public JTable2Pdf(JTable table) {
        this.table = table;
        JFrame frame = new JFrame("Getting Cell Values in JTable");
        JPanel panel = new JPanel();
//        String data[][] = {{"Angelina","Mumbai"},{"Martina","Delhi"}};
//
//        String col[] = {"Name","Address"};
//        DefaultTableModel model = new DefaultTableModel(data, col);
//        table = new JTable(model);
        JScrollPane pane = new JScrollPane(table);
        button=new JButton("Save to pdf");
        button.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent ae){
            System.out.println("sdfg");
        try{
        int count=table.getRowCount();
        Document document=new Document();
        PdfWriter.getInstance(document,new FileOutputStream("data.pdf"));
        document.open();
        PdfPTable tab = new PdfPTable(2);
        tab.addCell("Donor");
        tab.addCell("Donation");
        for(int i=0;i<count;i++){
        Object obj1 = GetData(table, i, 0);
        Object obj2 = GetData(table, i, 1);
        String value1=obj1.toString();
        String value2=obj2.toString();

        tab.addCell(value1);
        tab.addCell(value2);
        }
        document.add(tab);
        document.close();
        }
        catch(Exception e){}
        }
        });
        panel.add(pane);
        panel.add(button);
        frame.add(panel);
//        frame.setSize(500,500);
//        frame.setUndecorated(true);
//        frame.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
        frame.pack();
        frame.setVisible(true);
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public Object GetData(JTable table, int row_index, int col_index){
        return table.getModel().getValueAt(row_index, col_index);
    }
}

//
//import com.itextpdf.text.Document;
//import com.itextpdf.text.PageSize;
//import com.itextpdf.text.pdf.PdfContentByte;
//import com.itextpdf.text.pdf.PdfWriter;
//import java.awt.BorderLayout;
//import java.awt.Graphics2D;
//import java.awt.Shape;
//import java.io.FileOutputStream;
//import java.util.ArrayList;
//import javax.swing.JFrame;
//import javax.swing.JPanel;
//import javax.swing.JTable;
//
///**
// *
// * @author manish
// */
//
//public class JTable2Pdf extends JFrame {
//  private JTable table;
//  private ArrayList<ArrayList<String> > sample;
//  public JTable2Pdf(JTable table) {
//    getContentPane().setLayout(new BorderLayout());
//    this.table = table;
//  }
//  public void print() {
//    Document document = new Document(PageSize.A4.rotate());
//    try {
//      PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("jTable.pdf"));
//
//      document.open();
//      PdfContentByte cb = writer.getDirectContent();
//
//      cb.saveState();
//      Graphics2D g2 = cb.createGraphicsShapes(500, 500);
//
//      Shape oldClip = g2.getClip();
//      g2.clipRect(0, 0, 500, 500);
//
//      this.table.print(g2);
//      g2.setClip(oldClip);
//
//      g2.dispose();
//      cb.restoreState();
//    } catch (Exception e) {
//      System.err.println(e.getMessage());
//    }
//    document.close();
//  }
////  public static void main(String[] args) {
////    JTable2Pdf frame = new JTable2Pdf();
////    frame.pack();
////    frame.setVisible(true);
////    frame.print();
////  }
//}
//           