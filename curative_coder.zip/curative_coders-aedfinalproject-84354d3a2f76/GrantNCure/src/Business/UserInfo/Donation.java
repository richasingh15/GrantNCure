/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UserInfo;

import java.util.Date;

/**
 *
 * @author manish
 */
public class Donation {
    private double donation;
    private Date date;
    private DonorInfo donor;

    public Donation(double donation, DonorInfo donor) {
        this.donation = donation;
        this.date = new Date();
        this.donor = donor;
    }

    public double getDonation() {
        return donation;
    }

    public void setDonation(double donation) {
        this.donation = donation;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public DonorInfo getDonor() {
        return donor;
    }

    public void setDonor(DonorInfo donor) {
        this.donor = donor;
    }

    @Override
    public String toString() {
        return donation + "";
    }
    
}
