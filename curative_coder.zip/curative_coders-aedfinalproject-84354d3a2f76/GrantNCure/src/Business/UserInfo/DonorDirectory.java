/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UserInfo;

import java.util.ArrayList;

/**
 *
 * @author Richa Singh
 */
public class DonorDirectory {
    
    private ArrayList<DonorInfo> donorDirectory;
    
    public DonorDirectory(){
        if(this.donorDirectory == null)
            this.donorDirectory = new ArrayList<DonorInfo>();
    }

    public ArrayList<DonorInfo> getDonorDirectory() 
    {
        return donorDirectory;
    }

    public void setDonorDirectory(ArrayList<DonorInfo> donorDirectory) 
    {
        this.donorDirectory = donorDirectory;
    }
    public void deleteDonor(DonorInfo donor){
        donorDirectory.remove(donor);
    }
    public void addDonor(DonorInfo donor)
    {
        donorDirectory.add(donor);
        return;
    }
}
