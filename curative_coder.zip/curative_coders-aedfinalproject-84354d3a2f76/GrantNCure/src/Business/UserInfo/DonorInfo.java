/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.UserInfo;

import java.util.ArrayList;

/**
 *
 * @author Richa Singh
 */
public class DonorInfo {
    
    private String donorName;
    private String donorEmailID;
    private String address;
    private String city;
    private String state;
    private String phnNumber;
    private String password;
    private Double totalDonation = 0.0;
    private ArrayList<Donation> donations = new ArrayList<>();

    public ArrayList<Donation> getDonations() {
        return donations;
    }

    @Override
    public String toString() {
        return donorEmailID;
    }

    public void setDonations(ArrayList<Donation> donations) {
        this.donations = donations;
    }

    public Double getTotalDonation() {
        return totalDonation;
    }

    public void setTotalDonation(Double totalDonation) {
        this.totalDonation = totalDonation;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDonorName() {
        return donorName;
    }

    public void setDonorName(String donorName) {
        this.donorName = donorName;
    }

    public String getDonorEmailID() {
        return donorEmailID;
    }

    public void setDonorEmailID(String donorEmailID) {
        this.donorEmailID = donorEmailID;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPhnNumber() {
        return phnNumber;
    }

    public void setPhnNumber(String phnNumber) {
        this.phnNumber = phnNumber;
    }
    
    public void addDonation(Donation donation) {
        this.donations.add(donation);
    }
    
}
