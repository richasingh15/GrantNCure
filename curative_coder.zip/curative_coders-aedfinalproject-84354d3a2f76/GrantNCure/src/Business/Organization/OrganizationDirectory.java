/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organization;

import Business.Organization.Organization.Type;
import Business.Organization.Organization.TypeCharity;
import java.util.ArrayList;

/**
 *
 * @author raunak
 */
public class OrganizationDirectory {
    
    private ArrayList<Organization> organizationList;

    public OrganizationDirectory() {
        organizationList = new ArrayList();
    }

    public ArrayList<Organization> getOrganizationList() {
        return organizationList;
    }
    
    public Organization createOrganization(Type type){
        Organization organization = null;
        if (type.getValue().equals(Type.Hospitalist.getValue())){
            organization = new HospitalistOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(TypeCharity.CharityInventory.getValue())){
            organization = new CharityInventoryOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(TypeCharity.CharityWelfare.getValue())){
            organization = new CharityWelfareOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(TypeCharity.DonorAid.getValue())){
            organization = new DonorAidOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.Hospitalist.getValue())){
            organization = new HospitalistOrganization();
            organizationList.add(organization);
        }
        else if(type.getValue().equals(Type.Reception.getValue())){
            organization = new ReceptionOrganization();
            organizationList.add(organization);
        }
        return organization;
    }
    public Organization createOrganization(TypeCharity type){
        Organization organization = null;
        if (type.getValue().equals(Type.Hospitalist.getValue())){
            organization = new HospitalistOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(TypeCharity.CharityInventory.getValue())){
            organization = new CharityInventoryOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(TypeCharity.CharityWelfare.getValue())){
            organization = new CharityWelfareOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(TypeCharity.DonorAid.getValue())){
            organization = new DonorAidOrganization();
            organizationList.add(organization);
        }
        else if (type.getValue().equals(Type.Hospitalist.getValue())){
            organization = new HospitalistOrganization();
            organizationList.add(organization);
        }
        else if(type.getValue().equals(Type.Reception.getValue())){
            organization = new ReceptionOrganization();
            organizationList.add(organization);
        }
        return organization;
    }
}